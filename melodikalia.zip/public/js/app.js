import './bootstrap';

$(document).ready(function () {
    $(".dropdown-toggle").dropdown();
});
