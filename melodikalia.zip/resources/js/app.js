import './bootstrap';

$(document).ready(function () {
    $(".dropdown-toggle").dropdown();
});


$(document).ready(function () {
    $("#msg-error").delay(5000).fadeOut('slow');
    $("#msg-ok").delay(5000).fadeOut('slow');
});
