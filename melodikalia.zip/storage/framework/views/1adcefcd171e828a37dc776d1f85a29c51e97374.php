<?php echo app('Illuminate\Foundation\Vite')(['resources/css/register.css']); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/css/login.css']); ?>
<!DOCTYPE html>
<html>

<body>
    

    <?php $__env->startSection('content'); ?>
        <main class="d-flex flex-column align-items-center">
            <div class="wrapper">
                <div class="container">
                    <h1>Subir una canción</h1>
                    <?php if(isset($message)): ?>
                        <div class="p-3">
                            <?php echo $message; ?>

                        </div>
                    <?php endif; ?>

                    <form class="d-flex flex-column align-items-center" action="/songs" method="POST"
                        enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <label for="songName">Nombre</label>
                        <input type="text" name="songName">
                        <label for="genre">Genero</label>
                        <select name="genre">
                            <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($genre->id); ?>"><?php echo e($genre->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>

                        <!-- De momento solo archivos ".mp3" -->
                        <input type="file" id="music-file" name="musicFile" accept="audio/mp3" required>

                        <input type="hidden" name="userId" value="<?php echo e(session('user')->id); ?>">
                        <button id="buttonSub" type="submit" name="submit">Subir
                            Audio</button>
                    </form>
                    <div class="back-button d-flex justify-content-center">
                        <a href="/" class=" border border-dark d-flex justify-content-center p-2 w-25">Back</a>
                    </div>
                </div>
            </div>
        </main>
    <?php $__env->stopSection(); ?>
</body>

</html>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/songs/create.blade.php ENDPATH**/ ?>