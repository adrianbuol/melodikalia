<!DOCTYPE html>
<html>

<head>
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">
</head>

<body>
    

    <?php $__env->startSection('content'); ?>
        <main>
            <div class="d-flex flex-column justify-content-center align-items-center">
                <h3>CRUD - GENRES</h3>
                <div class="d-flex justify-content-md-between align-items-center p-3 w-75">
                    <a href="/genres/create" class="border border-dark col-2 d-flex justify-content-center">Create</a>
                </div>
                <div class="d-flex justify-content-center align-items-center ">
                    <table class="m-4">
                        <tr>
                            <td>ID</td>
                            <td>Name</td>
                            <td>Created At</td>
                            <td>Updated At</td>
                            <td colspan="2"></td>
                        </tr>
                        <?php $__currentLoopData = $allGenres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($genre->id); ?></td>
                                <td>
                                    <a href="/genres/<?php echo e($genre->id); ?>"><?php echo e($genre->name); ?></a>
                                </td>
                                <td><?php echo e($genre->created_at); ?></td>
                                <td><?php echo e($genre->updated_at); ?></td>
                                <td>
                                    
                                    <a href="/genres/<?php echo e($genre->id); ?>/edit"><i class="bi bi-pencil-square"></i></a>
                                </td>
                                <td>
                                    <form action="/genres/<?php echo e($genre->id); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button id="destroy" type="submit"><i class="bi bi-trash"></i></button>
                                        
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
                
                <a href="/admin" class="border border-dark col-2 d-flex justify-content-center">Back</a>
            </div>

        </main>
    <?php $__env->stopSection(); ?>
</body>

</html>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views//admin/genre.blade.php ENDPATH**/ ?>