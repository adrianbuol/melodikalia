<?php echo app('Illuminate\Foundation\Vite')(['resources/css/register.css']); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/css/login.css']); ?>
<!DOCTYPE html>
<html>

<body>
    

    <?php $__env->startSection('content'); ?>
        <main class="d-flex flex-column align-items-center">
            <div class="wrapper">
                <div class="container">
                    <h1>Crear Album</h1>
                    <?php if(isset($message)): ?>
                        <div class="p-3">
                            <?php echo $message; ?>

                        </div>
                    <?php endif; ?>

                    <form class="d-flex flex-column align-items-center" action="/albums" method="POST"
                        enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        <label for="name">Nombre del Album</label>
                        <input type="text" name="name">

                        <label>Cover</label>
                        <input type="file" id="img-file" name="img-file" accept="image/png, image/jpeg">


                        <button id="buttonSub" type="submit" name="submit">Registrar</button>
                    </form>

                    
                    <div class="back-button d-flex justify-content-center">
                        <a href="/users/<?php echo e(session('user')->id); ?>"
                            class="border border-dark d-flex justify-content-center p-2 w-25">Back</a>
                    </div>
                </div>
            </div>
        </main>
    <?php $__env->stopSection(); ?>
</body>

</html>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/albums/create.blade.php ENDPATH**/ ?>