<?php echo app('Illuminate\Foundation\Vite')(['resources/css/login.css']); ?>
<!DOCTYPE html>
<html>

<body>
    

    <?php $__env->startSection('content'); ?>
        

        <main>
            <div class="wrapper">
                <div class="container">
                    <h1>Iniciar Sesion</h1>
                    <?php if(isset($message)): ?>
                        <div class="p-3">
                            <?php echo $message; ?>

                        </div>
                    <?php endif; ?>
                    <form action="/login" method="post" class="form" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <input type="text" name="username" placeholder="Nombre de Usuario">
                        <input type="password" name="password" placeholder="Contraseña">

                        <button type="submit" name="submit" id="login-button">Entrar</button>
                    </form>
                </div>
            </div>
        </main>
    <?php $__env->stopSection(); ?>
</body>

</html>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views//login.blade.php ENDPATH**/ ?>