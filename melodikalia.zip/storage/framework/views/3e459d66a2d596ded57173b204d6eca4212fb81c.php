<?php echo app('Illuminate\Foundation\Vite')(['resources/css/register.css']); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/css/login.css']); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/js/register.js']); ?>
<!DOCTYPE html>
<html>

<body>
    

    <?php $__env->startSection('content'); ?>
        <main class="d-flex flex-column align-items-center">
            <div class="wrapper user-edit modify">
                <div class="container">
                    <h1>Modificar Usuario</h1>
                    <?php if(isset($message)): ?>
                        <div id="message" class="p-3">
                            <?php echo $message; ?>

                        </div>
                    <?php endif; ?>
                    <?php if(session('message')): ?>
                        <div id="message" class="p-3">
                            <?php echo session('message'); ?>

                        </div>
                    <?php endif; ?>

                    <form id="form-reg" action="/users/<?php echo e($user->id); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo e(method_field('PUT')); ?>

                        <div id="div1">
                            <label for="userName">Nombre de usuario</label>
                            <input type="text" name="userName" value="<?php echo e($user->username); ?>">
                        </div>
                        <div id="div2">
                            <label for="email">E-Mail</label>
                            <input type="email" name="email" value="<?php echo e($user->email); ?>">
                        </div>
                        <div id="div3">
                            <label for="password">Contraseña</label>
                            <input type="password" name="password" id="password" value="<?php echo e($user->password); ?>">
                        </div>
                        <div id="div4">
                            <label for="confirmPassword">Confirma Contraseña</label>
                            <input type="password" name="confirmPassword" id="confirmPassword"
                                value="<?php echo e($user->password); ?>">
                        </div>
                        <div id="div5">
                            <label for="avatar">Avatar</label>
                            <label for="avatar"><img id="img-modify"src="<?php echo e($imgPath); ?>"
                                    alt="<?php echo e($user->username); ?> avatar" /></label>
                            <input type="file" name="avatar" accept="image/png, image/jpeg"
                                value="<?php echo e($user->profile_pic); ?>">
                        </div>
                        <div id="div6">
                            <label for="name">Name: </label>
                            <input type="text" name="name" value="<?php echo e($user->name); ?>">
                        </div>
                        <div id="div7">
                            <label for="surname">Surname: </label>
                            <input type="text" name="surname" value="<?php echo e($user->surname); ?>">
                        </div>
                        <div id="div8" class="d-flex justify-content-center">
                            <button type="submit" name="submit"
                                class="border border-dark d-flex justify-content-center px-5 py-2 m-2 w-25">Actualizar</button>
                            <button type="reset"
                                class="border border-dark d-flex justify-content-center px-5 py-2 m-2 w-25">Reiniciar</button>

                        </div>
                    </form>
                    <?php if(session('user')->id == $user->id || session('user')->admin): ?>
                        <div class="d-flex justify-content-center">
                            
                            <a class="back-button border border-dark d-flex justify-content-center p-2"
                                href="/users/<?php echo e($user->id); ?>">Back</a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            </div>
        </main>
    <?php $__env->stopSection(); ?>
</body>

</html>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/users/edit.blade.php ENDPATH**/ ?>