<?php echo app('Illuminate\Foundation\Vite')(['resources/css/album.css']); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/css/profile.css']); ?>
<!DOCTYPE html>
<html>

<head>
</head>

<body>
    

    <?php $__env->startSection('content'); ?>
        <h1><?php echo e($genre->name); ?></h1>
        <?php if(session('message')): ?>
            <div class="p-3">
                <?php echo session('message'); ?>

            </div>
        <?php endif; ?>
        <div id="parent">
            <div id="songs-genre" class="m-2 p-2 border border-dark d-flex flex-column align-items-center">
                <table class="m-4">
                    <tr>
                        <td class="col-4">Name</td>
                        <td class="col-8">Song</td>
                    </tr>
                    <?php $__currentLoopData = $allSongs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $song): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($song->genre_id == $genre->id): ?>
                            <tr class="tableRow">
                                <td class="col-4"><a href="/songs/<?php echo e($song->id); ?>"><?php echo e($song->name); ?></a></td>
                                <td class="col-8">
                                    <audio controls>
                                        <source src="/storage/<?php echo e($song->song_path); ?>" type="audio/mp3">
                                    </audio>
                                </td>
                            </tr>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>


            </div>
            <div id="info-genre" class="m-2 p-2 border border-dark">
                <div class="campo">
                    <h6>Nombre del Genero: </h6>
                    <p> <?php echo e($genre->name); ?></p>
                </div>
                <div class="campo">
                    <h6>Creado: </h6>
                    <p> <?php echo e($genre->created_at); ?></p>
                </div>
                <div class="campo">
                    <h6>Ultima Modificacion: </h6>
                    <p> <?php echo e($genre->updated_at); ?></p>
                </div>
            </div>
            <div id="buttons-genre" class="d-flex m-2 p-2 border border-dark">
                <form class="m-1" action="/genres/<?php echo e($genre->id); ?>/edit" method="GET">
                    <?php echo csrf_field(); ?>
                    <input type="submit" value="Editar">
                </form>
                <form class="m-1" action="/genres/<?php echo e($genre->id); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <input type="submit" value="Eliminar">
                </form>
            </div>
        </div>
        <?php if(session('user')->admin): ?>
            <div class="d-flex justify-content-center">
                <a href="/genres" class="back-button border border-dark d-flex justify-content-center p-2 w-25">Back</a>
            </div>
        <?php endif; ?>
    <?php $__env->stopSection(); ?>

</body>

</html>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/genres/show.blade.php ENDPATH**/ ?>