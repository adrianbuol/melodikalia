<!DOCTYPE html>
<html>

<body>
    

    <?php $__env->startSection('content'); ?>
        <h4>Perfil</h4>
        <h6>ID: <span> <?php echo e(session('user')->id); ?></span> </h6>
        <h6>Username: <span> <?php echo e(session('user')->username); ?></span> </h6>
        <h6>Password: <span> <?php echo e(session('user')->password); ?></span> </h6>
        <h6>Email: <span> <?php echo e(session('user')->email); ?></span> </h6>
        <h6>Name: <span><?php echo e(session('user')->name); ?></span> </h6>
        <h6>Surname: <span><?php echo e(session('user')->surname); ?></span> </h6>
        <h6>Avatar: </h6>
        <img src="<?php echo e(session('user')->profile_pic); ?>" alt="<?php echo e(session('user')->username); ?> avatar" />
        <h6>Admin: <?php echo e(session('user')->admin); ?></h6>
        <h6>Created: <?php echo e(session('user')->created_at); ?></h6>
        <h6>Update: <?php echo e(session('user')->updated_at); ?></h6>
    <?php $__env->stopSection(); ?>

</body>

</html>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views//users/submenu/profile.blade.php ENDPATH**/ ?>