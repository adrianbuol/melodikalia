<?php echo app('Illuminate\Foundation\Vite')(['resources/css/header.css']); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css']); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.js']); ?>
<!DOCTYPE html>
<html>

<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">
    <link rel="icon" href="<?php echo e(asset('/images/icons/favicon.ico')); ?>">
    <title>Melodikalia</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
</head>

<body>
    <header>
        <nav class="d-flex justify-content-center align-items-center">
            <div id="home">
                <a href="/" class="border border-dark col-2 d-flex justify-content-center">Home</a>
                
                <?php if(session('user')): ?>
                    <?php
                        $user = session('user');
                    ?>
                    <h5>Bienvenido: <?php echo e($user->name); ?></h5>
                <?php endif; ?>
            </div>

            <div id="menu">
                
                <?php if(session('user')): ?>
                    <?php if($user->admin == 1): ?>
                        <a href="/admin" class="border border-dark col-2 d-flex justify-content-center">Admin</a>
                    <?php endif; ?>

                    <a href="/songs/create" class="border border-dark col-2 d-flex justify-content-center">Subir
                        Archivo</a>

                    
                    <div class="dropdown">
                        <a class="btn btn-secondary " href="#" role="button" id="dropdownMenuLink"
                            data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            Usuario
                        </a>

                        <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                            <a class="dropdown-item border-bottom" href="/users/<?php echo e($user->id); ?>">Perfil</a>
                            <a class="dropdown-item border-bottom" href="/like/<?php echo e($user->id); ?>">Me gusta</a>
                            <a class="dropdown-item border-bottom" href="/following/<?php echo e($user->id); ?>">Sigo</a>
                            <a class="dropdown-item border-bottom" href="/followers/<?php echo e($user->id); ?>">Me siguen</a>
                        </div>
                    </div>
                    <a href="/logout" class="border border-dark col-2 d-flex justify-content-center">Cerrar Sesion</a>
                <?php else: ?>
                    <a href="/users/create"
                        class="border border-dark col-2 d-flex justify-content-center">Registrarse</a>
                    <a href="/login" class="border border-dark col-2 d-flex justify-content-center">Iniciar
                        Sesion</a>
                <?php endif; ?>
            </div>
        </nav>
    </header>


    
    <div class="p-5">

        <?php echo $__env->yieldContent('content'); ?>
    </div>

    <!-- JavaScript Bundle with Popper -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous">
    </script>

</body>

</html>
<?php /**PATH /var/www/html/resources/views/layouts/app.blade.php ENDPATH**/ ?>