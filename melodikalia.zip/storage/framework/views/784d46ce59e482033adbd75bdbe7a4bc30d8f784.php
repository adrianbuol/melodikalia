<?php echo app('Illuminate\Foundation\Vite')(['resources/css/list.css']); ?>
<!DOCTYPE html>
<html>

<body>
    

    <?php $__env->startSection('content'); ?>
        <h1>Canciones que me gustan</h1>
        <div class="d-flex justify-content-center align-items-center">
            <table>
                <tr class="tableRow">
                    <td>Name</td>
                    <td>Autor</td>
                    <td>Song</td>
                    <td>Genre</td>
                </tr>
                <?php $__currentLoopData = $like; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $song): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="tableRow">
                        <td><a href="/songs/<?php echo e($song->id); ?>"><?php echo e($song->name); ?></a></td>
                        <td>
                            <?php $__currentLoopData = $allUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($user->id == $song->user_id): ?>
                                    <?php echo e($user->username); ?>

                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                        <td>
                            <audio controls>
                                <source src="/storage/<?php echo e($song->song_path); ?>" type="audio/mp3">
                            </audio>
                        </td>
                        <td>
                            <?php $__currentLoopData = $allGenres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($genre->id == $song->genre_id): ?>
                                    <?php echo e($genre->name); ?>

                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    <?php $__env->stopSection(); ?>
</body>

</html>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views//users/submenu/like.blade.php ENDPATH**/ ?>