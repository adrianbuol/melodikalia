<!DOCTYPE html>
<html>

<body>
    

    <?php $__env->startSection('content'); ?>
        <main>
            <div class="d-flex flex-column justify-content-center align-items-center">
                <h3>CRUD</h3>
                <div class="d-flex justify-content-md-between align-items-center p-3 w-75">
                    <a href="#">Albums</a>
                    <a href="#">Genres</a>
                    <a href="#">Songs</a>
                    <a href="#">Users</a>
                </div>
            </div>

        </main>
    <?php $__env->stopSection(); ?>
</body>

</html>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin.blade.php ENDPATH**/ ?>