<!DOCTYPE html>
<html>

<body>
    

    <?php $__env->startSection('content'); ?>
        <main>
            <div class="d-flex flex-column justify-content-center align-items-center">
                <h3>CRUD - ALBUMS</h3>
                <div class="d-flex justify-content-md-between align-items-center p-3 w-75">
                    <a href="#" class="border border-dark col-2 d-flex justify-content-center">Create</a>
                    <a href="#" class="border border-dark col-2 d-flex justify-content-center">Read</a>
                    <a href="#" class="border border-dark col-2 d-flex justify-content-center">Update</a>
                    <a href="#" class="border border-dark col-2 d-flex justify-content-center">Delete</a>
                </div>
                <a href="/admin" class="border border-dark col-2 d-flex justify-content-center">Back</a>
            </div>

        </main>
    <?php $__env->stopSection(); ?>
</body>

</html>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views//admin/album.blade.php ENDPATH**/ ?>