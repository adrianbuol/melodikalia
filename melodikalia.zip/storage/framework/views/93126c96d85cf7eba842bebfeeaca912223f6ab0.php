<?php echo app('Illuminate\Foundation\Vite')(['resources/css/list.css']); ?>
<!DOCTYPE html>
<html>

<body>
    

    <?php $__env->startSection('content'); ?>
        <h1>Usuarios que siguen a <?php echo e($user->username); ?>.</h1>
        <div>
            <table>
                <tr class="tableRow">
                    <td>Avatar</td>
                    <td>Username</td>
                    <td>Email</td>
                    <td>Name</td>
                    <td>Surname</td>
                </tr>
                <?php $__currentLoopData = $follower; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="tableRow">
                        <td>
                            <img src="/storage/<?php echo e($user->profile_pic); ?>" alt="<?php echo e($user->username); ?> avatar">
                        </td>
                        <td>
                            <a href="/users/<?php echo e($user->id); ?>"><?php echo e($user->username); ?></a>
                        </td>
                        <td><?php echo e($user->email); ?></td>
                        <td><?php echo e($user->name); ?></td>
                        <td><?php echo e($user->surname); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    <?php $__env->stopSection(); ?>
</body>

</html>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views//users/submenu/followers.blade.php ENDPATH**/ ?>