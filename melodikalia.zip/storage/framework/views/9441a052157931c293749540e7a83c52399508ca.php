<?php echo app('Illuminate\Foundation\Vite')(['resources/css/landing.css']); ?>



<?php $__env->startSection('content'); ?>
    <div class="row border-bottom w-50 mb-3">
        <h2>TOP - 5</h2>
    </div>

    
    <div class="row d-flex justify-content-center align-items-center">
        <?php $__currentLoopData = $topSongs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $song): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div
                class="cancion-landing cancion<?php echo e($songPageNum++); ?> d-flex flex-column justify-content-center align-items-center col-2 border border-dark p-3 m-2">
                <h4>
                    <a href="/songs/<?php echo e($song->id); ?>"><?php echo e($song->name); ?></a>
                </h4>
                <h5><?php $__currentLoopData = $allUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($user->id == $song->user_id): ?>
                            <?php echo e($user->username); ?>

                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </h5>

                <h6>
                    <?php $__currentLoopData = $allGenres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($genre->id == $song->genre_id): ?>
                            <?php echo e($genre->name); ?>

                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </h6>
                <p>Likes - <span><?php echo e($song->likes->count()); ?></span></p>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>


    <div class="row border-bottom mt-5 mb-5"></div>

    <div class="row border-bottom w-50 mb-3">
        <h2>Ultimas Subidas</h2>
    </div>

    
    <div class="row d-flex justify-content-center align-items-center">
        <?php $__currentLoopData = $latestSongs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $song): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div
                class="cancion-landing cancion<?php echo e($songPageNum++); ?> d-flex flex-column justify-content-center align-items-center col-2 border border-dark p-3 m-2">
                <h4>
                    <a href="/songs/<?php echo e($song->id); ?>"><?php echo e($song->name); ?></a>
                </h4>
                <h5>
                    <?php $__currentLoopData = $allUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($user->id == $song->user_id): ?>
                            <?php echo e($user->username); ?>

                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </h5>

                <h6>
                    <?php $__currentLoopData = $allGenres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($genre->id == $song->genre_id): ?>
                            <?php echo e($genre->name); ?>

                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </h6>
                <p>Likes - <span><?php echo e($song->likes->count()); ?></span></p>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="row border-bottom mt-5"></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/child.blade.php ENDPATH**/ ?>