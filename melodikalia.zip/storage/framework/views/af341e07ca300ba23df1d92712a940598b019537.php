<?php echo app('Illuminate\Foundation\Vite')(['resources/css/song.css']); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/css/profile.css']); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/css/reproductor.css']); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/js/song.js']); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/js/reproductor.js']); ?>

<!DOCTYPE html>
<html>

<head>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
</head>

<body>
    

    <?php $__env->startSection('content'); ?>
        <h4>Canción</h4>
        <div id="parent">
            <div id="song"
                class="m-2 p-2 border border-dark d-flex flex-column justify-content-center align-items-center">
                <div id="audio-player-container">
                    <audio src="<?php echo e($songPath); ?>" preload="metadata" loop></audio>
                    <p><?php echo e($songName); ?></p>

                    <button id="play-icon"></button>
                    <span id="current-time" class="time">0:00</span>
                    <input type="range" id="seek-slider" max="100" value="0">
                    <span id="duration" class="time">0:00</span>

                    <output id="volume-output">100</output>
                    <input type="range" id="volume-slider" max="100" value="100">
                    <button id="mute-icon"></button>
                </div>

                
                <div id="audio-player-mobile">
                    <h6><?php echo e($songName); ?> </h6>
                    <audio controls>
                        <source src="<?php echo e($songPath); ?>" type="audio/mp3">
                    </audio>
                </div>
            </div>

            <div id="info" class="m-2 p-2 border border-dark">
                <div class="campo">
                    <h6>Autor: </h6>
                    <a href="/users/<?php echo e($song->user_id); ?>"><?php echo e($author->username); ?></a>
                </div>
                <div class="campo">
                    <h6>Genero: </h6>
                    <p><?php echo e($genre); ?></p>
                </div>
                <div class="campo">
                    <h6>Nº Likes:</h6>
                    <p><?php echo e($numLikes); ?></p>
                    
                    <div id="campo-likes">
                        <?php if(session('user')): ?>
                            <?php if(!$likes): ?>
                                <a href="/songs/like/<?php echo e($song->id); ?>" id="like"><i class="bi bi-heart"></i></a>
                            <?php else: ?>
                                <a href="/songs/dislike/<?php echo e($song->id); ?>" id="remove-like"><i
                                        class="bi bi-heart-fill"></i></a>
                            <?php endif; ?>
                        <?php else: ?>
                            <a href="" id="like"><i class="bi bi-heart"></i></a>
                        <?php endif; ?>
                    </div>
                </div>

            </div>

            
            <div id="buttons" class="d-flex m-2 p-2 border border-dark">
                <?php if(session('user')): ?>
                    <button class="m-1" id="add-to-album">
                        <i class="bi bi-plus-circle mr-2"></i>
                        <span>Album</span>
                    </button>
                <?php endif; ?>

                
                <?php if(session('user')): ?>
                    <?php if(session('user')->id == $song->user_id || session('user')->admin): ?>
                        <form class="m-1" action="/songs/<?php echo e($song->id); ?>/edit" method="GET">
                            <?php echo csrf_field(); ?>
                            <input type="submit" value="Editar">
                        </form>
                        <form class="m-1" action="/songs/<?php echo e($song->id); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <input type="submit" value="Eliminar">
                        </form>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
        
        <div id="back-buttons" class="d-flex m-2 p-2 border border-dark">
            <div class="back-button d-flex justify-content-center">
                <a href="/users/<?php echo e($song->user_id); ?>" class="border border-dark d-flex justify-content-center p-3 m-3">Back
                    to User</a>
            </div>

            
            <?php if(session('user')): ?>
                <?php if(session('user')->admin): ?>
                    <div class="back-button d-flex justify-content-center">
                        <a href="/songs" class="border border-dark d-flex justify-content-center p-3 m-3">Back to crud</a>
                    </div>
                <?php endif; ?>
            <?php endif; ?>

        </div>
        <div id="add-to-album-modal">
            <h2>Añadir canción al Album</h2>
            <select id="lista-albumes"></select>
            <div class="d-flex">
                <button id="cerrar-album-modal" class="mr-2">Cancelar</button>
                <button id="aceptar-album-modal" class="mr-2" data-song-id="<?php echo e($song->id); ?>">Añadir</button>
            </div>
        </div>
    <?php $__env->stopSection(); ?>

</body>

</html>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/songs/show.blade.php ENDPATH**/ ?>