<?php echo app('Illuminate\Foundation\Vite')(['resources/css/register.css']); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/css/login.css']); ?>
<!DOCTYPE html>
<html>

<body>
    

    <?php $__env->startSection('content'); ?>
        <main class="d-flex flex-column align-items-center">
            <div class="wrapper">
                <div class="container">
                    <h1>Modificar Canción</h1>
                    <?php if(isset($message)): ?>
                        <div class="p-3">
                            <?php echo $message; ?>

                        </div>
                    <?php endif; ?>

                    <form class="d-flex flex-column align-items-center" action="/songs/<?php echo e($song->id); ?>" method="POST"
                        enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo e(method_field('PUT')); ?>

                        <label for="songName">Nombre de Canción: </label>
                        <input type="text" name="songName" value="<?php echo e($song->name); ?>">

                        <select class="mt-2" name="genre">
                            <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($song->genre_id == $genre->id): ?>
                                    <option value="<?php echo e($genre->id); ?>" selected><?php echo e($genre->name); ?></option>
                                <?php else: ?>
                                    <option value="<?php echo e($genre->id); ?>"><?php echo e($genre->name); ?></option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>

                        <!-- De momento solo archivos ".mp3" -->
                        <label for="musicFile">Archivo de audio</label>
                        <input type="file" id="musicFile" name="musicFile" accept="audio/mp3"
                            value="<?php echo e($song->song_path); ?>">

                        <div id="div8" class="d-flex justify-content-center">
                            <button type="submit" name="submit"
                                class="border border-dark d-flex justify-content-center px-5 py-2 m-2 w-25">Actualizar</button>
                            <button type="reset"
                                class="border border-dark d-flex justify-content-center px-5 py-2 m-2 w-25">Reiniciar</button>
                        </div>
                    </form>
                    <div class="back-button d-flex justify-content-center">
                        <a href="/songs/<?php echo e($song->id); ?>"
                            class="border border-dark d-flex justify-content-center p-2 w-25">Back</a>
                    </div>
                </div>
            </div>
        </main>
    <?php $__env->stopSection(); ?>
</body>

</html>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/songs/edit.blade.php ENDPATH**/ ?>