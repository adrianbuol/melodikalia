<?php echo app('Illuminate\Foundation\Vite')(['resources/css/album.css']); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/css/profile.css']); ?>
<!DOCTYPE html>
<html>

<body>
    

    <?php $__env->startSection('content'); ?>
        <h5 id="title" class="border-bottom border-dark"><?php echo e($album->name); ?></h5>
        <h6>Por <?php echo e($author); ?></h6>
        <div id="parent">
            <div id="album-cover"
                class="m-2 p-2 border border-dark d-flex flex-column justify-content-center align-items-center">
                <img src="<?php echo e($coverPath); ?>" alt="<?php echo e($album->name); ?> album cover">
            </div>
            <div id="songs-list" class="m-2 p-2 border border-dark">
                <?php $__currentLoopData = $albumSongs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $song): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="campo">
                        <h6>
                            <?php if($trackNum >= 10): ?>
                                <?php echo e($trackNum++); ?>

                            <?php else: ?>
                                0<?php echo e($trackNum++); ?>

                            <?php endif; ?>
                            -
                        </h6>
                        <h6><a href="/songs/<?php echo e($song->id); ?>"><?php echo e($song->name); ?></a></h6>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div id="buttons" class="d-flex m-2 p-2 border border-dark">

                <?php if(session('user')): ?>
                    <?php if(session('user')->id == $album->user_id || session('user')->admin): ?>
                        <form class="m-1" action="/albums/<?php echo e($album->id); ?>/edit" method="GET">
                            <?php echo csrf_field(); ?>
                            <input type="submit" value="Editar">
                        </form>
                        <form class="m-1" action="/genres/<?php echo e($album->id); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <input type="submit" value="Eliminar">
                        </form>
                    <?php endif; ?>
                <?php endif; ?>

            </div>
        </div>
        <div id="back-buttons" class="d-flex m-2 p-2 border border-dark">
            <div class="back-button d-flex justify-content-center">
                <a href="/users/<?php echo e($album->user_id); ?>"
                    class="border border-dark d-flex justify-content-center p-3 m-3">Back</a>
            </div>

            <?php if(session('user')): ?>
                <?php if(session('user')->admin): ?>
                    <div class="back-button d-flex justify-content-center">
                        <a href="/albums" class="border border-dark d-flex justify-content-center p-3 m-3">Back to Crud</a>
                    </div>
                <?php endif; ?>
            <?php endif; ?>

        </div>
    <?php $__env->stopSection(); ?>

</body>

</html>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/albums/show.blade.php ENDPATH**/ ?>