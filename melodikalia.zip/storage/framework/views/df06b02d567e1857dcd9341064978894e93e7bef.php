<!DOCTYPE html>
<html>

<body>
    

    <?php $__env->startSection('content'); ?>
        <h4>Perfil</h4>
    <?php $__env->stopSection(); ?>

</body>

</html>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views//users/profile.blade.php ENDPATH**/ ?>