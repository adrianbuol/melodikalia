<?php echo app('Illuminate\Foundation\Vite')(['resources/css/profile.css']); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/css/list.css']); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/js/profile.js']); ?>
<!DOCTYPE html>
<html>

<body>
    

    <?php $__env->startSection('content'); ?>
        <h4>Perfil</h4>
        <div id="parent-profile">
            <div id="avatar" class="m-2 p-2 d-flex flex-column justify-content-center align-items-center">
                <img src="<?php echo e($imgPath); ?>" alt="<?php echo e($user->username); ?> avatar" />
            </div>
            <div id="info-profile" class="m-2 p-2">
                <div class="campo">
                    <h6>Nombre de Usuario: </h6>
                    <p> <?php echo e($user->username); ?></p>
                </div>
                <div class="campo">
                    <h6>Email: </h6>
                    <p> <?php echo e($user->email); ?></p>
                </div>
                <div class="campo">
                    <h6>Nombre: </h6>
                    <p><?php echo e($user->name); ?></p>
                </div>
                <div class="campo">
                    <h6>Apellidos: </h6>
                    <p><?php echo e($user->surname); ?></p>
                </div>
            </div>
            <div id="buttons" class="d-flex justify-content-left align-items-center m-2">
                <?php if(session('user')): ?>
                    <?php if(session('user')->id == $user->id || session('user')->admin): ?>
                        <form class="m-1" action="/users/<?php echo e($user->id); ?>/edit" method="GET">
                            <?php echo csrf_field(); ?>
                            <input type="submit" value="Editar">
                        </form>
                        <form class="m-1" action="/users/<?php echo e($user->id); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <input type="submit" value="Eliminar">
                        </form>
                    <?php endif; ?>
                <?php endif; ?>

            </div>
            <div id="follows" class="d-flex justify-content-left align-items-center m-2">
                <div class="d-flex">
                    <a class="follow-link" href="/followers/<?php echo e($user->id); ?>">
                        <h4 class="m-3">Seguidores: <span><?php echo e($numFollowers); ?></span></h4>
                    </a>
                    <a class="follow-link" href="/following/<?php echo e($user->id); ?>">
                        <h4 class="m-3">Seguidos: <span><?php echo e($numFollows); ?></span></h4>
                    </a>
                </div>

                <div class="d-flex justify-content-left align-items-center">
                    <?php if(session('user')): ?>
                        <?php if(session('user')->id == $user->id): ?>
                        <?php endif; ?>
                        <?php if(session('user')->id != $user->id): ?>
                            <?php if(!$follows): ?>
                                <a href="/users/follow/<?php echo e($user->id); ?>" class="follow" id="do-follow">Seguir</a>
                            <?php else: ?>
                                <a href="/users/unfollow/<?php echo e($user->id); ?>" class="unfollow follow">Dejar de Seguir</a>
                            <?php endif; ?>
                        <?php endif; ?>
                    <?php endif; ?>

                </div>
            </div>
        </div>

        <div id="buttons-songs-albums">
            <button id="song-list" class="mr-2">Canciones</button>
            <button id="album-list" class="mr-2">Albums</button>


            <?php if(session('user')): ?>
                <?php if(session('user')->id == $user->id): ?>
                    <a id="btnCreateAlbum" href="/albums/create"
                        class="border border-dark d-flex justify-content-center">Nuevo
                        Album</a>
                <?php endif; ?>
            <?php endif; ?>

        </div>
        <div class="container-table">
            
            <table id="songs-user" class="w-100">
                <tr>
                    <td>Name</td>
                    <td>Autor</td>
                    <td>Genero</td>
                    <td>Fecha Creación</td>
                    <td colspan="2"></td>
                </tr>
                <?php if($userSongs->isEmpty()): ?>
                    <tr class="tableRow">
                        <td>⠀⠀</td>
                        <td>⠀⠀</td>
                        <td>⠀⠀</td>
                        <td>⠀⠀</td>
                        <td>⠀⠀</td>
                        <td>⠀⠀</td>
                    </tr>
                <?php endif; ?>
                <?php $__currentLoopData = $userSongs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $song): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="tableRow">
                        <td><a href="/songs/<?php echo e($song->id); ?>"><?php echo e($song->name); ?></a></td>
                        <td>
                            <a href="/users/<?php echo e($user->id); ?>"><?php echo e($user->username); ?></a>
                        </td>
                        
                        <td>
                            <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($genre->id == $song->genre_id): ?>
                                    <?php echo e($genre->name); ?>

                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                        <td><?php echo e($song->created_at); ?></td>
                        <?php if(session('user')): ?>
                            <?php if(session('user')->id == $user->id || session('user')->admin): ?>
                                <td>
                                    <a id="edit" href="/songs/<?php echo e($song->id); ?>/edit"><i
                                            class="bi bi-pencil-square"></i></a>
                                </td>
                                <td>
                                    <form action="/songs/<?php echo e($song->id); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button id="destroy" type="submit"><i class="bi bi-trash"></i></button>
                                    </form>
                                </td>
                            <?php endif; ?>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>

        <div class="container-table">
            
            <table id="albums-user" class="w-100">
                <tr>
                    <td>Nombre</td>
                    <td>Autor</td>
                    <td>Caratula</td>
                    <td>Fecha Creación</td>
                    <td colspan="2"></td>
                </tr>
                <?php if($userAlbums->isEmpty()): ?>
                    <tr class="tableRow">
                        <td>⠀⠀</td>
                        <td>⠀⠀</td>
                        <td>⠀⠀</td>
                        <td>⠀⠀</td>
                        <td>⠀⠀</td>
                        <td>⠀⠀</td>
                    </tr>
                <?php endif; ?>
                <?php $__currentLoopData = $userAlbums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $album): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="tableRow">
                        <td><a href="/albums/<?php echo e($album->id); ?>"><?php echo e($album->name); ?></a></td>
                        <td>
                            <?php echo e($user->username); ?>

                        </td>
                        <td>
                            <img class="border border-dark" src="/storage/<?php echo e($album->cover); ?>"
                                alt="<?php echo e($album->name); ?> image cover" />
                        </td>
                        <td><?php echo e($album->created_at); ?></td>

                        <?php if(session('user')): ?>
                            <?php if(session('user')->id == $user->id || session('user')->admin): ?>
                                <td>
                                    <a id="edit" href="/albums/<?php echo e($album->id); ?>/edit"><i
                                            class="bi bi-pencil-square"></i></a>
                                </td>
                                <td>
                                    <form action="/albums/<?php echo e($album->id); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button id="destroy" type="submit"><i class="bi bi-trash"></i></button>
                                    </form>
                                </td>
                            <?php endif; ?>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>

        <?php if(session('user')): ?>
            <?php if(session('user')->admin): ?>
                <div class="d-flex justify-content-center mt-2">
                    <a href="/users" class="back-button border border-dark d-flex justify-content-center p-2 w-25">Back to
                        Crud</a>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    <?php $__env->stopSection(); ?>

</body>

</html>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/users/submenu/profile.blade.php ENDPATH**/ ?>