<?php echo app('Illuminate\Foundation\Vite')(['resources/css/register.css']); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/css/login.css']); ?>
<!DOCTYPE html>
<html>

<body>
    

    <?php $__env->startSection('content'); ?>
        <main class="d-flex flex-column align-items-center">
            <div class="wrapper">
                <div class="container">
                    <h1>Crear nuevo género</h1>
                    <?php if(isset($message)): ?>
                        <div class="p-3">
                            <?php echo $message; ?>

                        </div>
                    <?php endif; ?>

                    <form class="d-flex flex-column align-items-center" action="/genres" method="post">
                        <?php echo csrf_field(); ?>
                        <label for="name">Introduce nombre para el genero</label>
                        <input type="text" name="name">
                        <div class="d-flex justify-content-center">
                            <button class="border border-dark d-flex justify-content-center px-5 py-2 m-2 w-25"
                                id="button-sub" type="submit" name="submit">Añadir</button>
                            <button class="border border-dark d-flex justify-content-center px-5 py-2 m-2 w-25"
                                id="button-res" type="reset">Reiniciar</button>
                        </div>
                    </form>

                    <div class="back-button d-flex justify-content-center">
                        <a href="/genres" class="border border-dark d-flex justify-content-center px-5 py-2 w-25">Back</a>
                    </div>
                </div>
            </div>
        </main>
    <?php $__env->stopSection(); ?>
</body>

</html>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/genres/create.blade.php ENDPATH**/ ?>