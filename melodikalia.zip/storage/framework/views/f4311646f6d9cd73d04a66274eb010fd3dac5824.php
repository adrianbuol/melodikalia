<?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css']); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/css/list.css']); ?>

<!DOCTYPE html>
<html>

<body>
    

    <?php $__env->startSection('content'); ?>
        <main>
            <div class="d-flex flex-column justify-content-center align-items-center">
                <h3>Administrador - SONGS</h3>
                <div class="d-flex justify-content-md-between align-items-center p-3 w-75">
                    <a id="btn-create" href="/songs/create"
                        class="border border-dark col-2 d-flex justify-content-center">Create</a>

                </div>
            </div>
            <div>
                <table class="m-4">
                    <tr class="tableRow">
                        <td>ID</td>
                        <td>Name</td>
                        <td>Autor</td>
                        <td>Genre</td>
                        <td>Created At</td>
                        <td>Updated At</td>
                        <td colspan="2"></td>
                    </tr>
                    <?php $__currentLoopData = $allSongs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $song): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="tableRow">
                            <td><?php echo e($song->id); ?></td>
                            <td><a href="/songs/<?php echo e($song->id); ?>"><?php echo e($song->name); ?></a></td>
                            <td>
                                <?php $__currentLoopData = $allUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($user->id == $song->user_id): ?>
                                        <?php echo e($user->username); ?>

                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>

                            <td>
                                <?php $__currentLoopData = $allGenres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($genre->id == $song->genre_id): ?>
                                        <?php echo e($genre->name); ?>

                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                            <td><?php echo e($song->created_at); ?></td>
                            <td><?php echo e($song->updated_at); ?></td>
                            <td>
                                <a href="/songs/<?php echo e($song->id); ?>/edit" id="edit"><i
                                        class="bi bi-pencil-square"></i></a>
                            </td>
                            <td>
                                <form action="/songs/<?php echo e($song->id); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button id="destroy" type="submit"><i class="bi bi-trash"></i></button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
            <div class="d-flex justify-content-center">
                <a href="/admin" class="back-button border border-dark d-flex justify-content-center p-2 w-25">Back</a>
            </div>
        </main>
    <?php $__env->stopSection(); ?>
</body>

</html>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/song.blade.php ENDPATH**/ ?>